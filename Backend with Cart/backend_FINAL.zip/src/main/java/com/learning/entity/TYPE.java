package com.learning.entity;

public enum TYPE {
	
	INDIAN,
	CHINESE,
	MEXICAN

}
