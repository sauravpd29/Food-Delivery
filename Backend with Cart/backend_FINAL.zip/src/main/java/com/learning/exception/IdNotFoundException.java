package com.learning.exception;

public class IdNotFoundException extends Exception {

	public IdNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
