package com.learning.exception.apierror;

public abstract class ApiSubError {

}
