package com.learning.exception;

public class AlreadyExistsException extends Exception {

	public AlreadyExistsException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
